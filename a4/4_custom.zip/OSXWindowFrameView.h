#import <Cocoa/Cocoa.h>

@interface OSXWindowFrameView : NSView
{
}

@end

